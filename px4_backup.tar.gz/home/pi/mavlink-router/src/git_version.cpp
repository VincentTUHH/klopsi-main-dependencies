#include "git_version.h"

const char *BUILD_VERSION = GIT_VERSION;
